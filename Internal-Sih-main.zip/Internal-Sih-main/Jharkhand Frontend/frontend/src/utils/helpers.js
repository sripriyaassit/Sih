export function formatDate(iso) {
  return new Date(iso).toLocaleString();
}
